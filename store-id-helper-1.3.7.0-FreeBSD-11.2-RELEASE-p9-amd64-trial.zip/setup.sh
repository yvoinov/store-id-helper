#!/bin/sh

DEST=$1

if [ "$1" = "-?" -o "$1" = "-h" -o "$1" = "-H" ]; then
 echo "To setup binary, run this script as follows:"
 echo "`basename $0` <your_destination_binary_dir>"
 exit 0;
fi

if [ ! -d "$DEST" ]; then
 echo "ERROR: Destination directory does not exists!"
 echo "       Check it or create first!"
 exit 1;
fi

if [ -x "store-id-helper" ]; then
 cp ./store-id-helper $DEST && echo "Ok."
else
 echo "ERROR: Binary not found! Unpack distribution archive first."
 exit 1;
fi
